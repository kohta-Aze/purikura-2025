# editor_app.py (最終決定版)

import os
import random
import tkinter as tk
from datetime import datetime
from tkinter import font
import qrcode

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageTk

# ===================================================================
# 専門家チームの設計図
# ===================================================================

class CameraCapture:
    """カメラからの映像取得を管理する専門家"""
    def __init__(self, camera_thread): self.thread = camera_thread
    def start(self): self.thread.start()
    def stop(self): self.thread.stop()
    def capture(self) -> cv2.typing.MatLike | None: return self.thread.get_latest_frame()
    def get_display_frame(self) -> ImageTk.PhotoImage | None:
        frame = self.thread.get_latest_frame()
        if frame is not None:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame_rgb)
            img.thumbnail((640, 480))
            return ImageTk.PhotoImage(image=img)
        return None

class AssetManager:
    """素材を管理する専門家"""
    def __init__(self, bg_folder: str = 'backgrounds', stamp_folder: str = 'stamps'):
        self.backgrounds = self._load_images(bg_folder)
        self.stamps = self._load_images(stamp_folder)
    def _load_images(self, folder: str) -> list[dict]:
        if not os.path.exists(folder): return []
        images = []
        for filename in sorted(os.listdir(folder)):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                try:
                    image_path = os.path.join(folder, filename)
                    image = Image.open(image_path).convert("RGBA")
                    images.append({'name': filename, 'image': image})
                except Exception as e: print(f"画像読み込みエラー: {e}")
        return images

class ImageEditor:
    """画像の各レイヤーを管理する専門家"""
    def __init__(self):
        self.photo_layer: Image.Image | None = None
        self.frame_layer: Image.Image | None = None
        self.drawing_layer: Image.Image | None = None
    def set_photo(self, cv2_image: cv2.typing.MatLike):
        original_image = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)
        self.photo_layer = Image.fromarray(original_image).convert("RGBA")
        self.drawing_layer = Image.new("RGBA", self.photo_layer.size, (0, 0, 0, 0))
    def set_frame(self, frame_image: Image.Image):
        if self.photo_layer: self.frame_layer = frame_image.resize(self.photo_layer.size)
    def get_drawing_canvas(self) -> Image.Image | None: return self.drawing_layer

class ImageCompositor:
    """画像を合成する専門家"""
    def __init__(self, editor: ImageEditor): self.editor = editor
    def create_final_image(self) -> Image.Image | None:
        if not self.editor.photo_layer: return None
        composite = self.editor.photo_layer.copy()
        if self.editor.frame_layer: composite = Image.alpha_composite(composite, self.editor.frame_layer)
        if self.editor.drawing_layer: composite = Image.alpha_composite(composite, self.editor.drawing_layer)
        return composite
    def get_final_image(self) -> Image.Image | None: return self.create_final_image()

class ImageSaver:
    """画像を保存する専門家"""
    def save(self, image: Image.Image, path: str = 'output', filename: str = None) -> str:
        if not os.path.exists(path): os.makedirs(path)
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"purikura_{timestamp}.png"
        save_path = os.path.join(path, filename)
        image.save(save_path, "PNG")
        print(f"画像を {save_path} に保存しました。")
        return save_path

# ===================================================================
# 画面の設計図 (View)
# ===================================================================

class StartFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        tk.Label(self, text="プリクラへようこそ！", font=("Yu Gothic UI", 40)).pack(pady=50)
        tk.Button(self, text="撮影を始める", font=("Yu Gothic UI", 20), command=controller.start_camera).pack(pady=20, ipady=10)

class ShootingFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent); self.controller = controller
        tk.Label(self, text="この画面で撮影するよ！", font=("Yu Gothic UI", 20)).pack(pady=5)
        self.preview_canvas = tk.Canvas(self, width=640, height=480, bg="black"); self.preview_canvas.pack(pady=5)
        self.countdown_text = self.preview_canvas.create_text(320, 240, text="", font=("Impact", 150, "bold"), fill="white")
        self.shoot_button = tk.Button(self, text="撮影！", font=("Yu Gothic UI", 20), command=self.controller.start_countdown)
        self.shoot_button.pack(pady=5, ipady=5)
        bottom_frame = tk.Frame(self); bottom_frame.pack(pady=5, fill="x", expand=True)
        self.photo_count_var = tk.StringVar(value="撮影枚数: 0枚")
        tk.Label(bottom_frame, textvariable=self.photo_count_var, font=("Yu Gothic UI", 14)).pack(side=tk.LEFT, padx=20)
        self.next_button = tk.Button(bottom_frame, text="編集にすすむ →", font=("Yu Gothic UI", 16, "bold"), state="disabled", command=self.controller.go_to_photo_selection)
        self.next_button.pack(side=tk.RIGHT, padx=20)
    def update_camera_feed(self):
        frame = self.controller.camera.get_display_frame()
        if frame:
            self.shoot_button.config(state="normal")
            self.preview_canvas.imgtk = frame
            self.preview_canvas.create_image(0, 0, image=frame, anchor="nw")
            self.preview_canvas.tag_raise(self.countdown_text)
        self.after(20, self.update_camera_feed)
    def update_countdown(self, number: int):
        if number > 0: self.preview_canvas.itemconfig(self.countdown_text, text=str(number))
        else:
            self.preview_canvas.itemconfig(self.countdown_text, text="パシャ！")
            self.after(500, lambda: self.preview_canvas.itemconfig(self.countdown_text, text=""))
    def update_photo_count(self, count: int):
        self.photo_count_var.set(f"撮影枚数: {count}枚")
        if count > 0: self.next_button.config(state="normal")
    def reset(self):
        self.update_photo_count(0); self.next_button.config(state="disabled")

class PhotoSelectionFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent); self.controller = controller
    def build_ui(self, photos):
        for widget in self.winfo_children(): widget.destroy()
        tk.Label(self, text="編集する写真を選んでね！", font=("Yu Gothic UI", 25, "bold")).pack(pady=10)
        canvas = tk.Canvas(self); scrollbar = tk.Scrollbar(self, orient="horizontal", command=canvas.xview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>",lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw"); canvas.configure(xscrollcommand=scrollbar.set)
        for cv2_image in photos:
            image_rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB); pil_image = Image.fromarray(image_rgb)
            pil_image.thumbnail((200, 200)); photo_image = ImageTk.PhotoImage(pil_image)
            button = tk.Button(scrollable_frame, image=photo_image, command=lambda p=cv2_image: self.controller.go_to_editing(p))
            button.image = photo_image; button.pack(side=tk.LEFT, padx=10, pady=10)
        retake_button = tk.Button(self, text="もう一度撮る", font=("Yu Gothic UI", 16), command=self.controller.retake_photos)
        finish_button = tk.Button(self, text="これで決定！", font=("Yu Gothic UI", 16, "bold"), command=self.controller.go_to_final_selection)
        canvas.pack(side="top", fill="x", expand=True, padx=20)
        scrollbar.pack(side=tk.BOTTOM, fill="x", padx=20)
        retake_button.pack(side=tk.LEFT, pady=10, padx=20)
        finish_button.pack(side=tk.RIGHT, pady=10, padx=20)

class EditingFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent); self.controller = controller
    def build_editor(self):
        for widget in self.winfo_children(): widget.destroy()
        tk.Label(self, text="編集してね！", font=("Yu Gothic UI", 20)).pack(pady=10)
        PurikuraEditor(parent=self, controller=self.controller).pack(fill="both", expand=True)

class PostEditChoiceFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        tk.Label(self, text="編集が完了したよ！", font=("Yu Gothic UI", 30, "bold")).pack(pady=40)
        tk.Label(self, text="次は何をする？", font=("Yu Gothic UI", 20)).pack(pady=10)
        tk.Button(self, text="他の写真を編集する", font=("Yu Gothic UI", 18), command=controller.go_to_photo_selection).pack(pady=10, ipady=5)
        tk.Button(self, text="保存する写真を選ぶ", font=("Yu Gothic UI", 18),command=controller.go_to_final_selection).pack(pady=10, ipady=5)

class FinalSelectionFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent); self.controller = controller; self.check_vars = []
    def build_ui(self, all_photos):
        for widget in self.winfo_children(): widget.destroy()
        tk.Label(self, text="保存する写真をえらんでね！", font=("Yu Gothic UI", 25, "bold")).pack(pady=10)
        canvas = tk.Canvas(self); scrollbar = tk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw"); canvas.configure(yscrollcommand=scrollbar.set)
        self.check_vars.clear()
        for cv2_image in all_photos:
            photo_frame = tk.Frame(scrollable_frame, borderwidth=2, relief="sunken")
            image_rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB); pil_image = Image.fromarray(image_rgb)
            pil_image.thumbnail((150, 150)); photo_image = ImageTk.PhotoImage(pil_image)
            label = tk.Label(photo_frame, image=photo_image); label.image = photo_image; label.pack(pady=5)
            check_var = tk.BooleanVar(value=True)
            self.check_vars.append((check_var, cv2_image))
            tk.Checkbutton(photo_frame, text="この写真を保存", variable=check_var, font=("Yu Gothic UI", 12)).pack(pady=5)
            photo_frame.pack(side=tk.LEFT, padx=10, pady=10, fill="y")
        upload_button = tk.Button(self, text="選んだ写真をアップロード！", font=("Yu Gothic UI", 18, "bold"), command=self.controller.upload_selected_photos)
        canvas.pack(side="top", fill="both", expand=True, padx=20)
        scrollbar.pack(side="left", fill="y")
        upload_button.pack(side=tk.BOTTOM, pady=10)
    def get_selected_photos(self):
        return [photo for var, photo in self.check_vars if var.get()]

class ThankYouFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.qr_image = None # 画像が消えないように、ここで覚えておく

        tk.Label(self, text="ありがとうございました！", font=("Yu Gothic UI", 40)).pack(pady=20)
        tk.Label(self, text="下のQRコードをスマホで読み取ってね", font=("Yu Gothic UI", 16)).pack()

        self.qr_label = tk.Label(self)
        self.qr_label.pack(pady=10)

        self.url_var = tk.StringVar()
        tk.Entry(self, textvariable=self.url_var, width=80, state='readonly').pack(pady=10)

        # --- ここから説明 ---
        # 「ホームへ戻る」ための新しいボタンを追加するよ！
        #
        # command（命令）には、さっき監督さんに新しく覚えてもらった
        # 「go_to_start」っていうお仕事を指定するんだ。
        # これで、このボタンが押されたらスタート画面に戻るようになるよ。
        # --- ここまで説明 ---
        home_button = tk.Button(self, text="ホームへ戻る", font=("Yu Gothic UI", 16, "bold"), command=controller.go_to_start)
        home_button.pack(pady=20, ipady=5) # ipadyでボタンを少し分厚くする
    def display_qr_code(self, url: str):
        self.url_var.set(url); img = qrcode.make(url)
        self.qr_image = ImageTk.PhotoImage(image=img); self.qr_label.config(image=self.qr_image)

class PurikuraEditor(tk.Frame):
    """編集画面のUI専門家"""
    def __init__(self, parent, controller):
        super().__init__(parent); self.controller = controller; self.editor = controller.editor
        self.compositor = controller.compositor; self.asset_manager = controller.asset_manager
        self.pen_color = "#FF69B4"; self.pen_width = 10; self.is_drawing = False
        self.last_x, self.last_y = None, None
        self._setup_ui(); self.update_display_image()
    def _setup_ui(self):
        self.image_label = tk.Label(self); self.image_label.pack(pady=5)
        self.image_label.bind("<B1-Motion>", self.draw_on_canvas); self.image_label.bind("<ButtonRelease-1>", self.stop_drawing)
        self.image_label.bind("<Button-1>", self.place_stamp_at_click)
        tool_frame = tk.Frame(self); tool_frame.pack(pady=2)
        action_frame = tk.Frame(self); action_frame.pack(pady=2)
        pen_buttons = [("キラキラピンク", "#FF69B4"), ("キラキラブルー", "#00BFFF"), ("くっきりブラック", "black"), ("けしゴム", "eraser"),]
        for name, color_code in pen_buttons:
            button = tk.Button(tool_frame, text=name, command=lambda c=color_code: self.change_pen_color(c)); button.pack(side=tk.LEFT, padx=3)
        tk.Button(tool_frame, text="ぜんぶ消す", command=self.clear_all_drawings).pack(side=tk.LEFT, padx=10)
        tk.Button(action_frame, text="フレーム選択", command=self.open_frame_selector).pack(side=tk.LEFT, padx=5)
        tk.Button(action_frame, text="スタンプ", command=self.open_stamp_selector).pack(side=tk.LEFT, padx=5)
        tk.Button(action_frame, text="これで決定！", command=self.controller.finish_editing).pack(side=tk.LEFT, padx=5)
    def change_pen_color(self, new_color: str): self.pen_color = new_color; self.pen_width = 50 if new_color == "eraser" else 10
    def clear_all_drawings(self):
        if self.editor.photo_layer: self.editor.drawing_layer = Image.new("RGBA", self.editor.photo_layer.size, (0, 0, 0, 0)); self.update_display_image()
    def draw_on_canvas(self, event):
        if not self.is_drawing: self.is_drawing = True; self.last_x, self.last_y = event.x, event.y; return
        if not self.editor.drawing_layer or not self.editor.photo_layer: return
        draw = ImageDraw.Draw(self.editor.drawing_layer)
        w, h = self.editor.photo_layer.size; disp_w, disp_h = self.display_image.width(), self.display_image.height()
        def scale(x, y): return (x * w / disp_w, y * h / disp_h)
        sl, sc = scale(self.last_x, self.last_y), scale(event.x, event.y)
        if self.pen_color == "eraser": draw.line([sl, sc], fill=(0,0,0,0), width=self.pen_width, joint="round")
        elif self.pen_color == "black": draw.line([sl, sc], fill=self.pen_color, width=self.pen_width, joint="round")
        else: self.draw_sparkly_line(draw, sl, sc)
        self.last_x, self.last_y = event.x, event.y; self.update_display_image()
    def draw_sparkly_line(self, draw, start, end):
        draw.line([start, end], fill=self.pen_color, width=self.pen_width, joint="round")
        num_sparks = int(((start[0] - end[0])**2 + (start[1] - end[1])**2)**0.5 / 2)
        for _ in range(num_sparks):
            r = random.random(); x, y = (start[0] * (1-r) + end[0] * r, start[1] * (1-r) + end[1] * r)
            dx, dy = (random.uniform(-self.pen_width*2, self.pen_width*2), random.uniform(-self.pen_width*2, self.pen_width*2))
            draw.point((x + dx, y + dy), fill=random.choice([self.pen_color, "white"]))
    def stop_drawing(self, event): self.is_drawing = False; self.last_x, self.last_y = None, None
    def place_stamp_at_click(self, event):
        if self.pen_color != "stamp_mode": return
        if hasattr(self, 'current_stamp') and self.editor.photo_layer and self.editor.drawing_layer:
            w, h = self.editor.photo_layer.size; disp_w, disp_h = self.display_image.width(), self.display_image.height()
            sw, sh = self.current_stamp.size
            x, y = int(event.x*w/disp_w) - sw//2, int(event.y*h/disp_h) - sh//2
            self.editor.drawing_layer.paste(self.current_stamp, (x, y), mask=self.current_stamp)
            self.update_display_image()
    def activate_stamp_mode(self, stamp_image: Image.Image):
        self.pen_color = "stamp_mode"; self.current_stamp = stamp_image.copy(); self.current_stamp.thumbnail((150, 150))
    def update_display_image(self):
        if not self.editor.photo_layer: return
        preview_image = self.compositor.create_final_image()
        if preview_image:
            resized = preview_image.copy(); resized.thumbnail((640, 480))
            self.display_image = ImageTk.PhotoImage(resized); self.image_label.config(image=self.display_image)
    def open_frame_selector(self):
        if not self.asset_manager.backgrounds: print("フレーム用画像がありません。"); return
        BackgroundSelector(self, self.asset_manager.backgrounds, self.set_frame)
    def open_stamp_selector(self):
        if not self.asset_manager.stamps: print("スタンプ用画像がありません。"); return
        StampSelector(self, self.asset_manager.stamps, self.activate_stamp_mode)
    def set_frame(self, frame_image: Image.Image):
        self.editor.set_frame(frame_image); self.update_display_image()

class BackgroundSelector(tk.Toplevel):
    def __init__(self, parent, assets, callback):
        super().__init__(parent); self.title("フレーム選択"); self.transient(parent); self.grab_set(); self.callback = callback
        canvas = tk.Canvas(self); scrollbar = tk.Scrollbar(self, orient="vertical", command=canvas.yview); frame = tk.Frame(canvas)
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw"); canvas.configure(yscrollcommand=scrollbar.set)
        for i, asset in enumerate(assets):
            img = asset['image'].copy(); img.thumbnail((100, 100)); photo = ImageTk.PhotoImage(img)
            btn = tk.Button(frame, image=photo, command=lambda a=asset: self.select(a)); btn.image = photo
            btn.grid(row=i//4, column=i%4, padx=5, pady=5)
        canvas.pack(side="left", fill="both", expand=True); scrollbar.pack(side="right", fill="y")
    def select(self, asset): self.callback(asset['image']); self.destroy()

class StampSelector(tk.Toplevel):
    def __init__(self, parent, assets, callback):
        super().__init__(parent); self.title("スタンプ選択"); self.transient(parent); self.grab_set(); self.callback = callback
        canvas = tk.Canvas(self); scrollbar = tk.Scrollbar(self, orient="vertical", command=canvas.yview); frame = tk.Frame(canvas)
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw"); canvas.configure(yscrollcommand=scrollbar.set)
        for i, asset in enumerate(assets):
            img = asset['image'].copy(); img.thumbnail((80, 80)); photo = ImageTk.PhotoImage(img)
            btn = tk.Button(frame, image=photo, command=lambda a=asset: self.select(a)); btn.image = photo
            btn.grid(row=i//5, column=i%5, padx=5, pady=5)
        canvas.pack(side="left", fill="both", expand=True); scrollbar.pack(side="right", fill="y")
    def select(self, asset): self.callback(asset['image']); self.destroy()