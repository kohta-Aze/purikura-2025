# main_app.py (最終決定版)

import io
import queue
import threading
import time
import tkinter as tk
from tkinter import font
import json

import cv2
import numpy as np
import qrcode
import requests
from PIL import Image, ImageTk

# 専門家チームの道具箱である「editor_app.py」から、必要な専門家を呼び出す
from editor_app import (AssetManager, CameraCapture, ImageCompositor,
                         ImageEditor, ImageSaver, EditingFrame,
                         FinalSelectionFrame, PhotoSelectionFrame,
                         PostEditChoiceFrame, ShootingFrame, StartFrame,
                         ThankYouFrame)


# 【ここからコピー】
class ImageUploader:
    """AWSに画像をアップロードする専門家"""
    def __init__(self, api_url: str):
        self.api_url = api_url

    def upload_images(self, pil_images: list[Image.Image]) -> str | None:
        """
        【この関数の役割】
        複数の画像をまとめてアップロードする、新しいお仕事だよ！
        """
        try:
            # --- ここから説明 ---
            # まずは、受付係（Lambda）に「これから〇枚の写真を送るよ！」って
            # 申請書（JSONデータ）を送るんだ。
            # --- ここまで説明 ---
            photo_count = len(pil_images)
            if photo_count == 0:
                return None
            
            headers = {'Content-Type': 'application/json'}
            payload = json.dumps({'photo_count': photo_count})
            
            # 申請書を送って、〇枚分のアップロード場所リストをもらう
            response = requests.post(f"{self.api_url}/upload", data=payload, headers=headers)
            response.raise_for_status()

            data = response.json()
            upload_urls = data.get('uploadUrls')
            viewer_url = data.get('viewerUrl')

            if not upload_urls or not viewer_url or len(upload_urls) != photo_count:
                print("エラー: APIからのレスポンスが不正です。")
                return None

            # --- ここから説明 ---
            # もらったURLのリストと、写真のリストを、一つずつペアにして
            # 順番にアップロードしていくんだ。
            # zipっていう魔法を使うと、２つのリストを同時にループできるから便利だよ。
            # --- ここまで説明 ---
            print(f"{photo_count}枚の写真をアップロードします...")
            for image, url in zip(pil_images, upload_urls):
                img_byte_arr = io.BytesIO()
                image.save(img_byte_arr, format='PNG')
                img_byte_arr.seek(0)
                
                upload_response = requests.put(url, data=img_byte_arr, headers={'Content-Type': 'image/png'})
                upload_response.raise_for_status()
                print(" - 1枚アップロード完了！")

            print("すべてのアップロードが成功しました！")
            return viewer_url # 最後に、QRコード用のURLを返す

        except requests.exceptions.RequestException as e:
            print(f"アップロードエラー: {e}")
            return None
# 【ここまでコピー】

class CameraThread(threading.Thread):
    """カメラを裏で動かし続ける専門家"""
    def __init__(self, device_id: int = 0):
        super().__init__(daemon=True)
        self.device_id = device_id
        self.frame_queue = queue.Queue(maxsize=1)
        self.stop_event = threading.Event()
        self.cap = None
    def run(self):
        self.cap = cv2.VideoCapture(self.device_id)
        if not self.cap.isOpened(): print("!!! カメラエラー: カメラを開けませんでした。"); return
        while not self.stop_event.is_set():
            ret, frame = self.cap.read()
            if not ret: time.sleep(0.1); continue
            if self.frame_queue.full(): self.frame_queue.get_nowait()
            self.frame_queue.put(frame)
        self.cap.release()
    # 【ここからコピー】
    def get_latest_frame(self):
        """最新のカメラフレームを取得する"""
        # --- ここから説明 ---
        # これが、タイミングのズレをなくすための、新しい賢いルールだよ！
        #
        # 「try:」は「とりあえず、これをやってみて！」という意味。
        # 「self.frame_queue.get(timeout=1)」は、
        # 「コンベアからパンを1個取ってきて。もし無かったら、最大で1秒だけ待ってあげてね」
        # という、新しい命令なんだ。
        #
        # 「except queue.Empty:」は、「もし1秒待っても、結局パンが来なかったら…」という意味。
        # その時は、諦めて「None（何も無かったよ）」と報告するんだ。
        # --- ここまで説明 ---
        try:
            # 1秒間、キューに新しいフレームが入るのを待つ
            return self.frame_queue.get(timeout=1)
        except queue.Empty:
            # 1秒待ってもフレームが来なかった場合
            print("待機しましたが、カメラから新しいフレームを取得できませんでした。")
            return None
# 【ここまでコピー】
    def stop(self):
        self.stop_event.set()


class MainApplication(tk.Tk):
    """アプリ全体の流れを管理する「監督」さん"""
    # 【ここからコピー】
    def __init__(self):
        super().__init__()
        self.title("プリクラアプリ ver1.2 (安定版)")
        self.geometry("800x650")

        API_GATEWAY_URL = "https://p372expvm7.execute-api.ap-northeast-1.amazonaws.com/v1"

        # --- ここから説明 ---
        # 専門家たちを準備するけど、カメラの専門家だけは、
        # まだ呼ばずに席だけ用意しておくよ（Noneは「空っぽ」っていう意味）。
        # カメラマンは、撮影が始まる直前に呼ぶのが一番効率的だからね！
        # --- ここまで説明 ---
        self.camera = None # ★カメラは、ここではまだ呼ばない！
        self.asset_manager = AssetManager()
        self.editor = ImageEditor()
        self.compositor = ImageCompositor(self.editor)
        self.saver = ImageSaver()
        self.uploader = ImageUploader(API_GATEWAY_URL)
        self.captured_photos = []
        self.edited_photos = []

        # (この後の container や self.frames の設定は変更なし)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1); container.grid_columnconfigure(0, weight=1)
        self.frames = {}
        frame_classes = (StartFrame, ShootingFrame, PhotoSelectionFrame, EditingFrame,
                         PostEditChoiceFrame, FinalSelectionFrame, ThankYouFrame)
        for F in frame_classes:
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartFrame)
# 【ここまでコピー】

    def show_frame(self, frame_class):
        self.frames[frame_class].tkraise()

    # 【ここからコピー】
    def start_camera(self):
        """「撮影を始める」ボタンが押された時の、新しいお仕事"""
        print("遷移: スタート -> 撮影画面")
        
        # --- ここから説明 ---
        # ここが今回の改造のメインイベントだよ！
        #
        # １．まず、前の人が遊んだ写真データが残っていたら大変だから、
        # 　 「撮った写真アルバム」と「編集した写真アルバム」を、まっさらにするんだ。
        #
        # ２．次に、ピカピカの新人カメラマン（CameraThread）と、
        # 　 そのマネージャー（CameraCapture）を、新しく呼び出すんだ。
        #
        # これで、いつ遊んでも、必ずまっさらな状態からスタートできるようになったよ！
        # --- ここまで説明 ---

        # ステップ１：全データをリセット
        self.captured_photos.clear()
        self.edited_photos.clear()

        # ステップ２：新しいカメラ専門家を準備
        self.camera = CameraCapture(CameraThread())
        self.camera.start()
        
        time.sleep(0.5)
        self.frames[ShootingFrame].shoot_button.config(state="disabled")
        self.frames[ShootingFrame].reset()
        self.show_frame(ShootingFrame)
        self.frames[ShootingFrame].update_camera_feed()
# 【ここまでコピー】

    def start_countdown(self, count: int = 3):
        shooting_frame = self.frames[ShootingFrame]
        shooting_frame.shoot_button.config(state="disabled")
        if count > 0:
            shooting_frame.update_countdown(count)
            self.after(1000, lambda: self.start_countdown(count - 1))
        else:
            shooting_frame.update_countdown(0)
            self.capture_photo()
            self.after(500, lambda: shooting_frame.shoot_button.config(state="normal"))

    def capture_photo(self):
        captured_frame = self.camera.capture()
        if captured_frame is not None:
            self.captured_photos.append(captured_frame)
            self.frames[ShootingFrame].update_photo_count(len(self.captured_photos))
        else:
            print("警告: フレームのキャプチャに失敗しました。")

    def go_to_photo_selection(self):
        all_photos = self.captured_photos + self.edited_photos
        if not all_photos: return
        self.frames[PhotoSelectionFrame].build_ui(all_photos)
        self.show_frame(PhotoSelectionFrame)

    def retake_photos(self):
        self.show_frame(ShootingFrame)

    def go_to_editing(self, selected_photo):
        # 参照を比較するために、NumPy配列として比較する
        is_in_captured = any(np.array_equal(selected_photo, p) for p in self.captured_photos)
        is_in_edited = any(np.array_equal(selected_photo, p) for p in self.edited_photos)

        if is_in_captured:
            self.captured_photos = [p for p in self.captured_photos if not np.array_equal(p, selected_photo)]
        if is_in_edited:
            self.edited_photos = [p for p in self.edited_photos if not np.array_equal(p, selected_photo)]

        self.editor.set_photo(selected_photo)
        self.frames[EditingFrame].build_editor()
        self.show_frame(EditingFrame)

    def finish_editing(self):
        edited_image = self.compositor.get_final_image()
        if edited_image:
            cv_image = cv2.cvtColor(np.array(edited_image), cv2.COLOR_RGBA2BGRA)
            self.edited_photos.append(cv_image)
        self.show_frame(PostEditChoiceFrame)

    def go_to_final_selection(self):
        all_photos = self.captured_photos + self.edited_photos
        self.frames[FinalSelectionFrame].build_ui(all_photos)
        self.show_frame(FinalSelectionFrame)

    # 【ここからコピー】
    def upload_selected_photos(self):
        """選んだ写真をアップロード"""
        print("処理: 選択された写真をアップロード")
        photos_to_upload = self.frames[FinalSelectionFrame].get_selected_photos()

        if not photos_to_upload:
            print("アップロードする写真が選択されていません。")
            return

        # --- ここから説明 ---
        # OpenCVの画像形式（cv2_image）のリストを、
        # アップロード担当さんが扱えるPillowの画像形式（pil_image）のリストに、
        # まとめて変換するお仕事だよ。
        # --- ここまで説明 ---
        pil_images = []
        for cv2_image in photos_to_upload:
            image_rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(image_rgb)
            pil_images.append(pil_image)

        # 新しくなった、超優秀なアップロード担当さんにお仕事をお願いする！
        viewer_url = self.uploader.upload_images(pil_images) # ★upload_image -> upload_images に変更！

        if viewer_url:
            self.frames[ThankYouFrame].display_qr_code(viewer_url)
            self.show_frame(ThankYouFrame)
        else:
            print("エラー: アップロードに失敗しました。")
    # 【ここからコピー】
    def go_to_start(self):
        """
        【この関数の役割】
        「ホームへ戻る」ボタンが押された時に呼ばれる、新しいお仕事だよ。
        
        ただ一言、「スタート画面を表示して！」と命令するだけの、
        とってもシンプルな役割なんだ。
        """
        print("遷移: サンキュー画面 -> スタート画面")
        self.show_frame(StartFrame)
# 【ここまでコピー】
# 【ここまでコピー】

    # 【ここからコピー】
    def shutdown(self):
        """アプリ終了処理"""
        print("アプリを終了します。")
        # --- ここから説明 ---
        # もし、一度も撮影をしないでアプリを閉じた場合、
        # カメラマン（self.camera）はまだ呼ばれていない状態だよね。
        #
        # 「if self.camera:」の一文は、
        # 「もしカメラマンがちゃんと呼ばれていたら、お仕事終了の挨拶をしてね」
        # という意味なんだ。これで、どんな状況でアプリを閉じてもエラーが起きなくなるよ。
        # --- ここまで説明 ---
        if self.camera: # ★カメラマンがいる時だけ、ストップをかける
            self.camera.stop()
        self.destroy()
# 【ここまでコピー】

if __name__ == "__main__":
    app = MainApplication()
    app.protocol("WM_DELETE_WINDOW", app.shutdown)
    app.mainloop()